
     - ImageBatch is an utility for batch conversion of images,
       based on LibGD (http://www.libgd.org/) and EasyBMP (http://easybmp.sourceforge.net/) graphic libraries. 

     - Supported formats: JPEG, PNG, GIF, BMP.

     - With this utility you can convert your images from one format to another, resize, rotate, crop, 
       flip them and draw watermarks as well.
       
     - ImageBatch is free and lightweight, installation is not required.

     - Homepage of ImageBatch is http://imagebatch.org/, here you go to submit your feedback if any.

     - Current version: 1.2

     - ImageBatch is written by Dmitry Kopasov